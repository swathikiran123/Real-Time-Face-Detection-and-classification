import cv2
import multiprocessing

# write a function to handle a single input

def display_single_video(video_path,window_name,model_path):
    detector = cv2.CascadeClassifier(model_path)
    video = cv2.VideoCapture(video_path)
    video.set(cv2.CAP_PROP_FPS, 5)
    while True:
        ret,frame = video.read()
        if ret:
            resize_frame = cv2.resize(frame,dsize=None,fx=0.5,fy=0.5)
            gray = cv2.cvtColor(resize_frame,cv2.COLOR_BGR2GRAY)
            results = detector.detectMultiScale(gray,1.4,4)
            if len(results) >=1:
                x,y,w,h = results[0][0]*2,results[0][1]*2,results[0][2]*2,results[0][3]*2
                cv2.rectangle(frame,(x,y),(x+w,y+h),(0,0,255),3)
            cv2.imshow(window_name,frame)
            if cv2.waitKey(30) & 0xFF == ord('q'):
                break
        else:
            break
    
    cv2.destroyAllWindows()
    video.release()

def display_two_videos(video_path1,video_path2,model_path):
    

    multiprocessing.set_start_method(method="spawn",force=True)

    process1 = multiprocessing.Process(target=display_single_video,args=(video_path1,"video1",model_path))
    process2 = multiprocessing.Process(target=display_single_video,args=(video_path2,"video2",model_path))

    process1.start()
    process2.start()

    process1.join()
    process2.join()

if __name__ =="__main__":
    path1 = "trimmed.mp4"
    path2 = "trimmed.mp4"
    path3 = "har_face.xml"

    display_two_videos(video_path1=path1,video_path2=path2,model_path=path3)
