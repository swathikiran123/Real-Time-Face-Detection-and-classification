import cv2
import multiprocessing


# lets take 2 images and display both of the images at once 

# write a function to handle a single input

def display_single_image(img_path,window_name):
    img = cv2.imread(img_path)
    cv2.imshow(window_name,img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def displaying_2_images(img_path1,img_path2):
    multiprocessing.set_start_method("spawn",force=True)
    # targetfunction, args
    process1 = multiprocessing.Process(target=display_single_image,args=(img_path1,"charan1"))
    process2 = multiprocessing.Process(target=display_single_image,args=(img_path2,"charan2"))

    process1.start()
    process2.start()

    process1.join()
    process2.join()

if __name__ == "__main__":
    displaying_2_images(img_path1="coffee.jpg",img_path2="coffee.jpg")